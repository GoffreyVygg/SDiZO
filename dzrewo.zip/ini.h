// Ilosc wierzcholkow
#define V 10
int G[V][V];

// Liczba iteracji
int iteracje = 10;

// Funkcja wczytujaca macierz kwadratowa z pliku
void WczytajZPliku() {
	FILE *plikWejsciowy;
	// Wybor macierzy
	if((plikWejsciowy = fopen("macierz10.txt","r")) == NULL) {
		printf("Blad odczytu\n");
		exit(1);
	}
	int wczytanaLiczba;
	for(int i = 0; i < V; i++) {
		for(int j = 0; j < V; j++) {
			fscanf(plikWejsciowy, "%d,", &wczytanaLiczba);
			G[i][j] = wczytanaLiczba;
		}
	}
	fclose(plikWejsciowy);	
}